// ==UserScript==
// @name         Links on Disney+ - IMDB, Rotten Tomatoes, Metacritic, YouTube Trailers
// @description  Adds links for searching titles from disneyplus.com
// @version      0.5
// @author       mica
// @namespace    greasyfork.org/users/12559
// @include      https://www.disneyplus.com/*
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js
// @license      MIT
// ==/UserScript==

$('head').append(`
<style>
    #sbox {margin: -16px 0 0 10px}
    #sbox a {margin: 0 8px}
    #sbox img {width: 24px; height: 24px;}
</style>
`);
var url
function checkReady() {
    if (document.getElementsByTagName('body')[0].getAttribute('style') == null) {
        setTimeout(checkReady, 1000);
    } else {
        setInterval(function() {
            if (url != location.href) {
                url = location.href;
                $('#sbox').remove();
                setTimeout(function() {
                    var title = $('h1').text();
                    var year = $('.metadata:first').text().replace(/[^0-9]...+/g,'');
                    var mc = 'https://www.metacritic.com/search/all/' + encodeURIComponent(title.replace(/\*|\//g,' ')) + '/results';
                    var imdb = 'https://www.imdb.com/find?s=tt&ref_=fn_tt&q=' + encodeURIComponent(title) + ' ' + year; 
                    var rt = 'https://www.rottentomatoes.com/search/?search=' + encodeURIComponent(title) + ' ' + year;
                    var yt = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(title) + ' trailer'
                    $('[data-gv2containerkey|="contentMeta"]').find('p:first').after([
                        $('<div>').attr('id', 'sbox').append([
                            $('<a>').attr('href', mc).attr('target', '_blank').html('<img src="https://www.metacritic.com/favicon.ico">'),
                            $('<a>').attr('href', imdb).attr('target', '_blank').html('<img src="https://www.imdb.com/favicon.ico">'),
                            $('<a>').attr('href', rt).attr('target', '_blank').html('<img src="https://www.rottentomatoes.com/assets/pizza-pie/images/favicon.ico">'),
                            $('<a>').attr('href', yt).attr('target', '_blank').html('<img src="https://www.youtube.com/s/desktop/f4861452/img/favicon_32x32.png">')
                        ])
                    ]);
                }, 2000);
            }
        }, 100);
    }
}
checkReady();
