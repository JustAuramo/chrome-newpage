// ==UserScript==
// @name         Kick.com - Auto set stream quality
// @namespace    https://greasyfork.org/en/users/991548-revboxx
// @version      1.0.3
// @author       revboxx
// @description  Switches the stream quality from auto to 1080p/720p (highest available).
// @match        *://*.kick.com/*
// @grant        none
// @run-at       document-start
// @license      MIT
// ==/UserScript==

let previousUrl = location.href;
const observer = new MutationObserver(function(mutations) {
  if (document.location.href !== previousUrl && previousUrl !== '') {
    previousUrl = document.location.href;
    switch (true) {
      case document.location.href === 'https://kick.com':
        break;
      case document.location.href === 'https://kick.com/':
        break;
      case document.location.href.includes('https://kick.com/community-guidelines'):
        break;
      case document.location.href.includes('https://kick.com/dmca-policy'):
        break;
      case document.location.href.includes('https://kick.com/categories'):
        break;
      case document.location.href.includes('https://kick.com/dashboard'):
        break;
      case document.location.href.includes('https://kick.com/video'):
        CheckForStream();
        break;
      default:
        CheckForStream();
    }
  }
});
const config = {subtree: true, childList: true};
observer.observe(document, config);

async function CheckForStream() {
  var found = false;
  var loop = 0;
  var qselect = document.querySelector("button[title='Quality']");
  while (!found && loop < 25) {
    loop++;
    if (qselect) {
      try { SetStreamQuality(); } catch {}
      found = true;
      return;
    }
    var qselect = document.querySelector("button[title='Quality']");
    await new Promise(r => setTimeout(r, 750));
  }
}

async function SetStreamQuality() {
  var found = false;
  var loop = 0;
  while (!found && loop < 20) {
    loop++;
    if (document.evaluate("//span[text()='1080p60']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
      document.evaluate("//span[text()='1080p60']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.parentNode.click();
      found = true;
    }
    else if (document.evaluate("//span[text()='1080p']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
      document.evaluate("//span[text()='1080p']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.parentNode.click();
      found = true;
    }
    else if (document.evaluate("//span[text()='720p60']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
      document.evaluate("//span[text()='720p60']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.parentNode.click();
      found = true;
    }
    else if (document.evaluate("//span[text()='720p']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
      document.evaluate("//span[text()='720p']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.parentNode.click();
      found = true;
    }
    else if (document.evaluate("//span[text()='Auto']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
      document.evaluate("//span[text()='Auto']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.parentNode.click();
      found = true;
    }
    await new Promise(r => setTimeout(r, 200));
  }
  document.querySelector("button[title='Quality']").click();
  document.querySelector("button[title='Quality']").click();
}

switch (true) {
  case document.location.href == 'https://kick.com':
    break;
  case document.location.href == 'https://kick.com/':
    break;
  case document.location.href.includes('https://kick.com/community-guidelines'):
    break;
  case document.location.href.includes('https://kick.com/dmca-policy'):
    break;
  case document.location.href.includes('https://kick.com/categories'):
    break;
  case document.location.href.includes('https://kick.com/dashboard'):
    break;
  case document.location.href.includes('https://kick.com/video'):
    CheckForStream();
    break;
  default:
    CheckForStream();
}